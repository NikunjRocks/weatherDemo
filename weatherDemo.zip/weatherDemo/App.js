/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useEffect, useState} from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  useColorScheme,
  Text,
  ScrollView,
  View,
} from 'react-native';

import {Colors} from 'react-native/Libraries/NewAppScreen';

const App = () => {
  const isDarkMode = useColorScheme() === 'dark';

  const backgroundStyle = {
    backgroundColor: isDarkMode ? Colors.darker : Colors.lighter,
  };

  const [currentWeather, setCurrentWeather] = useState(null);

  const weatherResponse = res => {
    setCurrentWeather(res);
    console.log('res====== ', res);
  };

  useEffect(() => {
    getWeather(weatherResponse);
  }, []);

  return (
    <SafeAreaView style={backgroundStyle}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />

      <View style={{width: '100%', height: '100%'}}>
        <ScrollView style={{width: '100%', height: '100%'}}>
          <Text style={{marginTop: 20}}>London's Weather</Text>
          <Text style={{marginTop: 40}}>
            {currentWeather ? JSON.stringify(currentWeather) : 'loading....'}
          </Text>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export const getWeather = cb => {
  var requestOptions = {
    method: 'GET',
    redirect: 'follow',
  };

  fetch('https://www.metaweather.com/api/location/44418/', requestOptions)
    .then(response => response.text())
    .then(result => cb(JSON.parse(result)))
    .catch(error => console.log('error', error));
};

const styles = StyleSheet.create({
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
});

export default App;
